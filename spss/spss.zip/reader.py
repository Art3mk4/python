import savReaderWriter
with savReaderWriter.SavReader("someFile.sav", returnHeader=True) as reader:
    header = next(reader)
    for line in reader:
        print line